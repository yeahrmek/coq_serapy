# Changelog (unreleased)

## [Unreleased]

### Added

- in `finmap.v`:
  + lemma `fsetU11`
  + definitions `fcover` and `trivIfset`
  + lemmas `leq_card_fsetU`, `leq_card_fcover`
  + lemma `trivIfsetP`, `fcover_imfset`, `big_trivIfset`
  + lemma `partition_disjoint_bigfcup`

### Changed

### Renamed

- in `finmap.v`:
  + `big_setU1` -> `big_fsetU1`

### Removed

### Infrastructure

### Misc

# CoqdocJS Usage Example
This folder contains a minimal example to use CoqdocJS in your project.

You can build the docs with `make html`.

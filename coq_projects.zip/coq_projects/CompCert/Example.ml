open IO_Monad
open IO_Pervasives
open IO_RawChar

(** val print_bool : bool -> unit coq_IO **)

let print_bool = fun b k -> k (Pervasives.print_endline (Pervasives.string_of_bool b))

(** val int_constant : int **)

let int_constant = 3

(** val f : unit coq_IO **)

let f =
  IO.while_loop (fun b ->
    if b
    then IO.bind (print_bool false) (fun _ ->
           IO.bind
             (print_endline
               (to_ostring ('H'::('e'::('l'::('l'::('o'::[]))))))) (fun _ ->
             IO.ret None))
    else IO.bind (print_bool true) (fun _ ->
           IO.bind (print_int int_constant) (fun _ ->
             IO.bind print_newline (fun _ -> IO.ret (Some true))))) false

(** val y : unit **)

let y =
  IO.unsafe_run f

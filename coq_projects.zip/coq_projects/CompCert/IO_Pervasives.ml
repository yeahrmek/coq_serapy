open IO_Monad

(** val print_int : int -> unit coq_IO **)

let print_int = fun n k -> k (Pervasives.print_int     n)

(** val print_endline : String.t -> unit coq_IO **)

let print_endline = fun s k -> k (Pervasives.print_endline s)

(** val print_newline : unit coq_IO **)

let print_newline = fun   k -> k (Pervasives.print_newline ())

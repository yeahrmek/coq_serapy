
type nat =
| O
| S of nat

open Datatypes
open ExtrOcamlIntConv
open IO_Monad
open IO_Pervasives
open Nat

(** val print_nat : nat -> unit coq_IO **)

let print_nat n =
  print_int (int_of_nat n)

(** val output_byte_nat : Pervasives.out_channel -> nat -> unit coq_IO **)

let output_byte_nat h n =
  output_byte h (int_of_nat n)

(** val input_byte_nat : Pervasives.in_channel -> nat coq_IO **)

let input_byte_nat h =
  IO.map nat_of_int (input_byte h)

(** val incr_ref_nat : nat ref -> unit coq_IO **)

let incr_ref_nat r =
  IO.bind (read_ref r) (fun n -> write_ref r (succ n))

(** val decr_ref_nat : nat ref -> unit coq_IO **)

let decr_ref_nat r =
  IO.bind (read_ref r) (fun n -> write_ref r (pred n))

(** val exit_nat : nat -> 'a1 coq_IO **)

let exit_nat n =
  exit (int_of_nat n)

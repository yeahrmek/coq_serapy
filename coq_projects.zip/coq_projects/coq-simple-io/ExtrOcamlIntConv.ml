open Datatypes

(** val int_of_nat : nat -> int **)

let int_of_nat =
  let rec loop acc = function
  | O -> acc
  | S n0 -> loop (succ acc) n0
  in loop 0

(** val int_natlike_rec : 'a1 -> ('a1 -> 'a1) -> int -> 'a1 **)

let int_natlike_rec = fun fO fS ->
 let rec loop acc i = if i <= 0 then acc else loop (fS acc) (i-1)
 in loop fO

(** val nat_of_int : int -> nat **)

let nat_of_int =
  int_natlike_rec O (fun x -> S x)

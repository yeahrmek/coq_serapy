open Datatypes

(** val succ : nat -> nat **)

let succ x =
  S x

(** val pred : nat -> nat **)

let pred n = match n with
| O -> n
| S u -> u

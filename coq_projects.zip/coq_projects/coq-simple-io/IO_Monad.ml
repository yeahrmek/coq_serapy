
type 'a coq_IO = ('a -> Obj.t) -> Obj.t

module IO =
 struct
  (** val ret : 'a1 -> 'a1 coq_IO **)

  let ret = fun a k -> k a

  (** val bind : 'a1 coq_IO -> ('a1 -> 'a2 coq_IO) -> 'a2 coq_IO **)

  let bind = fun io_a io_b k -> io_a (fun a -> io_b a k)

  (** val map : ('a1 -> 'a2) -> 'a1 coq_IO -> 'a2 coq_IO **)

  let map f m =
    bind m (fun a -> ret (f a))

  (** val unsafe_run : unit coq_IO -> unit **)

  let unsafe_run = fun io -> Obj.magic io (fun () -> ())
 end

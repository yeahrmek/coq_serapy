open IO_Monad

type 'a ref = 'a Pervasives.ref

(** val print_char : char -> unit coq_IO **)

let print_char = fun c k -> k (Pervasives.print_char    c)

(** val print_int : int -> unit coq_IO **)

let print_int = fun n k -> k (Pervasives.print_int     n)

(** val print_string : String.t -> unit coq_IO **)

let print_string = fun s k -> k (Pervasives.print_string  s)

(** val print_endline : String.t -> unit coq_IO **)

let print_endline = fun s k -> k (Pervasives.print_endline s)

(** val print_newline : unit coq_IO **)

let print_newline = fun   k -> k (Pervasives.print_newline ())

(** val open_out : String.t -> Pervasives.out_channel coq_IO **)

let open_out = fun s k -> k (Pervasives.open_out s)

(** val close_out : Pervasives.out_channel -> unit coq_IO **)

let close_out = fun h k -> k (close_out h)

(** val output_byte : Pervasives.out_channel -> int -> unit coq_IO **)

let output_byte = fun h b k -> k (Pervasives.output_byte h b)

(** val open_in : String.t -> Pervasives.in_channel coq_IO **)

let open_in = fun s k -> k (Pervasives.open_in s)

(** val close_in : Pervasives.in_channel -> unit coq_IO **)

let close_in = fun h k -> k (Pervasives.close_in h)

(** val input_byte : Pervasives.in_channel -> int coq_IO **)

let input_byte = fun h k -> k (Pervasives.input_byte h)

(** val new_ref : 'a1 -> 'a1 ref coq_IO **)

let new_ref = fun x k -> k (Pervasives.ref x)

(** val read_ref : 'a1 ref -> 'a1 coq_IO **)

let read_ref = fun r k -> k (Pervasives.(!) r)

(** val write_ref : 'a1 ref -> 'a1 -> unit coq_IO **)

let write_ref = fun r x k -> k (Pervasives.(:=) r x)

(** val exit : int -> 'a1 coq_IO **)

let exit = fun n k -> k (Pervasives.exit n)
